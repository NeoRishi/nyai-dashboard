#!/bin/bash
# ─────────────────────────────────────────────────────────────
# NyAI Dashboard — Hostinger VPS Deploy Script
# Run this ON the VPS after uploading the project files.
# Usage: sudo bash deploy/setup.sh
# ─────────────────────────────────────────────────────────────

set -e

APP_DIR="/opt/nyai-dashboard"
DOMAIN="nyai.neorishi.io"

echo "╔═══════════════════════════════════════════════╗"
echo "║   NyAI Dashboard — Hostinger VPS Setup        ║"
echo "╚═══════════════════════════════════════════════╝"

# ── 1. System packages ──────────────────────────────────────
echo ""
echo "▸ Step 1/6: Installing system packages..."
apt update -qq
apt install -y -qq python3 python3-venv python3-pip nginx certbot python3-certbot-nginx > /dev/null 2>&1
echo "  ✓ Python3, Nginx, Certbot installed"

# ── 2. Copy app files ───────────────────────────────────────
echo ""
echo "▸ Step 2/6: Setting up application directory..."
mkdir -p $APP_DIR
# Copy backend (with built frontend in static/)
cp -r backend/* $APP_DIR/backend/ 2>/dev/null || cp -r backend $APP_DIR/
echo "  ✓ Files copied to $APP_DIR"

# ── 3. Python virtual environment ───────────────────────────
echo ""
echo "▸ Step 3/6: Creating Python environment..."
python3 -m venv $APP_DIR/venv
$APP_DIR/venv/bin/pip install --quiet fastapi uvicorn[standard]
echo "  ✓ Virtual environment ready"

# ── 4. Verify app runs ──────────────────────────────────────
echo ""
echo "▸ Step 4/6: Verifying NyAI engine..."
cd $APP_DIR/backend
$APP_DIR/venv/bin/python -c "
from nyai.scenarios import run_all_scenarios
results = run_all_scenarios()
divergent = sum(1 for r in results if r['diverges'])
print(f'  ✓ All 5 scenarios loaded, {divergent}/5 diverge from baseline')
"

# ── 5. Systemd service ──────────────────────────────────────
echo ""
echo "▸ Step 5/6: Configuring systemd service..."
cp $APP_DIR/deploy/nyai.service /etc/systemd/system/nyai.service 2>/dev/null || \
cat > /etc/systemd/system/nyai.service << 'EOF'
[Unit]
Description=NyAI Dashboard - Nyaya-Grounded Reasoning Engine
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/nyai-dashboard/backend
ExecStart=/opt/nyai-dashboard/venv/bin/uvicorn main:app --host 127.0.0.1 --port 8000 --workers 2
Restart=always
RestartSec=5
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable nyai
systemctl restart nyai
sleep 2

# Check if service is running
if systemctl is-active --quiet nyai; then
    echo "  ✓ NyAI service running on port 8000"
else
    echo "  ✗ Service failed to start. Check: journalctl -u nyai -n 20"
    exit 1
fi

# ── 6. Nginx reverse proxy ──────────────────────────────────
echo ""
echo "▸ Step 6/6: Configuring Nginx..."

# Write nginx config (HTTP-only first, certbot adds SSL)
cat > /etc/nginx/sites-available/nyai << NGINX
server {
    listen 80;
    server_name $DOMAIN;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 60s;
    }

    location /assets/ {
        alias $APP_DIR/backend/static/assets/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
}
NGINX

# Enable site
ln -sf /etc/nginx/sites-available/nyai /etc/nginx/sites-enabled/nyai
rm -f /etc/nginx/sites-enabled/default 2>/dev/null

# Test and reload nginx
nginx -t 2>/dev/null
systemctl reload nginx
echo "  ✓ Nginx configured for $DOMAIN"

echo ""
echo "═══════════════════════════════════════════════"
echo "  NyAI Dashboard deployed!"
echo ""
echo "  HTTP:  http://$DOMAIN"
echo "  Test:  curl http://localhost:8000/api/health"
echo ""
echo "  Next: Set up SSL with:"
echo "    sudo certbot --nginx -d $DOMAIN"
echo ""
echo "  Useful commands:"
echo "    systemctl status nyai     # check status"
echo "    journalctl -u nyai -f     # live logs"
echo "    systemctl restart nyai    # restart app"
echo "═══════════════════════════════════════════════"
