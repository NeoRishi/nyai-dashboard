#!/bin/bash
# ─────────────────────────────────────────────────────────────
# NyAI Dashboard — Quick Update (run after code changes)
# Usage: sudo bash deploy/update.sh
# ─────────────────────────────────────────────────────────────

set -e

APP_DIR="/opt/nyai-dashboard"

echo "▸ Copying updated files..."
cp -r backend/* $APP_DIR/backend/

echo "▸ Restarting NyAI service..."
systemctl restart nyai
sleep 2

if systemctl is-active --quiet nyai; then
    echo "✓ NyAI updated and running"
    curl -s http://localhost:8000/api/health | python3 -m json.tool
else
    echo "✗ Restart failed. Check: journalctl -u nyai -n 20"
    exit 1
fi
